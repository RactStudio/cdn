/*
 * RactStudio WHMCS Ajax Hosting Cart Order Form - JavaScript and jQuery
 *
 * This file defines the js rules used by the rs_ajax_hosting_cart order form.
 *
 * @project   WHMCS (OrderForm)
 * @version   3.0
 * @package   rs_ajax_hosting_cart
 * @author    RactStudio <ractstudio@gmail.com>
 * @copyright Copyright (c) Ract Software Studio 2015-2017
 * @link      https://codecanyon.net/item/powerful-ajax-hosting-cart-onepage-order-configure-checkout-whmcs-order-form-template/21131358?ref=RactStudio
 */

/*!
 * iCheck v1.0.2, http://git.io/arlzeA
 * ===================================
 * Powerful jQuery and Zepto plugin for checkboxes and radio buttons customization
 *
 * (c) 2013 Damir Sultanov, http://fronteed.com
 * MIT Licensed
 */

(function($) {

  // Cached vars
  var _iCheck = 'iCheck',
    _iCheckHelper = _iCheck + '-helper',
    _checkbox = 'checkbox',
    _radio = 'radio',
    _checked = 'checked',
    _unchecked = 'un' + _checked,
    _disabled = 'disabled',a
    _determinate = 'determinate',
    _indeterminate = 'in' + _determinate,
    _update = 'update',
    _type = 'type',
    _click = 'click',
    _touch = 'touchbegin.i touchend.i',
    _add = 'addClass',
    _remove = 'removeClass',
    _callback = 'trigger',
    _label = 'label',
    _cursor = 'cursor',
    _mobile = /ipad|iphone|ipod|android|blackberry|windows phone|opera mini|silk/i.test(navigator.userAgent);

  // Plugin init
  $.fn[_iCheck] = function(options, fire) {

    // Walker
    var handle = 'input[type="' + _checkbox + '"], input[type="' + _radio + '"]',
      stack = $(),
      walker = function(object) {
        object.each(function() {
          var self = $(this);

          if (self.is(handle)) {
            stack = stack.add(self);
          } else {
            stack = stack.add(self.find(handle));
          }
        });
      };

    // Check if we should operate with some method
    if (/^(check|uncheck|toggle|indeterminate|determinate|disable|enable|update|destroy)$/i.test(options)) {

      // Normalize method's name
      options = options.toLowerCase();

      // Find checkboxes and radio buttons
      walker(this);

      return stack.each(function() {
        var self = $(this);

        if (options == 'destroy') {
          tidy(self, 'ifDestroyed');
        } else {
          operate(self, true, options);
        }

        // Fire method's callback
        if ($.isFunction(fire)) {
          fire();
        }
      });

    // Customization
    } else if (typeof options == 'object' || !options) {

      // Check if any options were passed
      var settings = $.extend({
          checkedClass: _checked,
          disabledClass: _disabled,
          indeterminateClass: _indeterminate,
          labelHover: true
        }, options),

        selector = settings.handle,
        hoverClass = settings.hoverClass || 'hover',
        focusClass = settings.focusClass || 'focus',
        activeClass = settings.activeClass || 'active',
        labelHover = !!settings.labelHover,
        labelHoverClass = settings.labelHoverClass || 'hover',

        // Setup clickable area
        area = ('' + settings.increaseArea).replace('%', '') | 0;

      // Selector limit
      if (selector == _checkbox || selector == _radio) {
        handle = 'input[type="' + selector + '"]';
      }

      // Clickable area limit
      if (area < -50) {
        area = -50;
      }

      // Walk around the selector
      walker(this);

      return stack.each(function() {
        var self = $(this);

        // If already customized
        tidy(self);

        var node = this,
          id = node.id,

          // Layer styles
          offset = -area + '%',
          size = 0 + (area * 2) + '%',
          layer = {
            position: 'absolute',
            top: offset,
            left: offset,
            display: 'block',
            width: size,
            height: size,
            margin: 0,
            padding: 0,
            background: '#fff',
            border: 0,
            opacity: 0
          },

          // Choose how to hide input
          hide = _mobile ? {
            position: 'absolute',
            visibility: 'hidden'
          } : area ? layer : {
            position: 'absolute',
            opacity: 0
          },

          // Get proper class
          className = node[_type] == _checkbox ? settings.checkboxClass || 'i' + _checkbox : settings.radioClass || 'i' + _radio,

          // Find assigned labels
          label = $(_label + '[for="' + id + '"]').add(self.closest(_label)),

          // Check ARIA option
          aria = !!settings.aria,

          // Set ARIA placeholder
          ariaID = _iCheck + '-' + Math.random().toString(36).substr(2,6),

          // Parent & helper
          parent = '<div class="' + className + '" ' + (aria ? 'role="' + node[_type] + '" ' : ''),
          helper;

        // Set ARIA "labelledby"
        if (aria) {
          label.each(function() {
            parent += 'aria-labelledby="';

            if (this.id) {
              parent += this.id;
            } else {
              this.id = ariaID;
              parent += ariaID;
            }

            parent += '"';
          });
        }

        // Wrap input
        parent = self.wrap(parent + '/>')[_callback]('ifCreated').parent().append(settings.insert);

        // Layer addition
        helper = $('<ins class="' + _iCheckHelper + '"/>').css(layer).appendTo(parent);

        // Finalize customization
        self.data(_iCheck, {o: settings, s: self.attr('style')}).css(hide);
        !!settings.inheritClass && parent[_add](node.className || '');
        !!settings.inheritID && id && parent.attr('id', _iCheck + '-' + id);
        parent.css('position') == 'static' && parent.css('position', 'relative');
        operate(self, true, _update);

        // Label events
        if (label.length) {
          label.on(_click + '.i mouseover.i mouseout.i ' + _touch, function(event) {
            var type = event[_type],
              item = $(this);

            // Do nothing if input is disabled
            if (!node[_disabled]) {

              // Click
              if (type == _click) {
                if ($(event.target).is('a')) {
                  return;
                }
                operate(self, false, true);

              // Hover state
              } else if (labelHover) {

                // mouseout|touchend
                if (/ut|nd/.test(type)) {
                  parent[_remove](hoverClass);
                  item[_remove](labelHoverClass);
                } else {
                  parent[_add](hoverClass);
                  item[_add](labelHoverClass);
                }
              }

              if (_mobile) {
                event.stopPropagation();
              } else {
                return false;
              }
            }
          });
        }

        // Input events
        self.on(_click + '.i focus.i blur.i keyup.i keydown.i keypress.i', function(event) {
          var type = event[_type],
            key = event.keyCode;

          // Click
          if (type == _click) {
            return false;

          // Keydown
          } else if (type == 'keydown' && key == 32) {
            if (!(node[_type] == _radio && node[_checked])) {
              if (node[_checked]) {
                off(self, _checked);
              } else {
                on(self, _checked);
              }
            }

            return false;

          // Keyup
          } else if (type == 'keyup' && node[_type] == _radio) {
            !node[_checked] && on(self, _checked);

          // Focus/blur
          } else if (/us|ur/.test(type)) {
            parent[type == 'blur' ? _remove : _add](focusClass);
          }
        });

        // Helper events
        helper.on(_click + ' mousedown mouseup mouseover mouseout ' + _touch, function(event) {
          var type = event[_type],

            // mousedown|mouseup
            toggle = /wn|up/.test(type) ? activeClass : hoverClass;

          // Do nothing if input is disabled
          if (!node[_disabled]) {

            // Click
            if (type == _click) {
              operate(self, false, true);

            // Active and hover states
            } else {

              // State is on
              if (/wn|er|in/.test(type)) {

                // mousedown|mouseover|touchbegin
                parent[_add](toggle);

              // State is off
              } else {
                parent[_remove](toggle + ' ' + activeClass);
              }

              // Label hover
              if (label.length && labelHover && toggle == hoverClass) {

                // mouseout|touchend
                label[/ut|nd/.test(type) ? _remove : _add](labelHoverClass);
              }
            }

            if (_mobile) {
              event.stopPropagation();
            } else {
              return false;
            }
          }
        });
      });
    } else {
      return this;
    }
  };

  // Do something with inputs
  function operate(input, direct, method) {
    var node = input[0],
      state = /er/.test(method) ? _indeterminate : /bl/.test(method) ? _disabled : _checked,
      active = method == _update ? {
        checked: node[_checked],
        disabled: node[_disabled],
        indeterminate: input.attr(_indeterminate) == 'true' || input.attr(_determinate) == 'false'
      } : node[state];

    // Check, disable or indeterminate
    if (/^(ch|di|in)/.test(method) && !active) {
      on(input, state);

    // Uncheck, enable or determinate
    } else if (/^(un|en|de)/.test(method) && active) {
      off(input, state);

    // Update
    } else if (method == _update) {

      // Handle states
      for (var each in active) {
        if (active[each]) {
          on(input, each, true);
        } else {
          off(input, each, true);
        }
      }

    } else if (!direct || method == 'toggle') {

      // Helper or label was clicked
      if (!direct) {
        input[_callback]('ifClicked');
      }

      // Toggle checked state
      if (active) {
        if (node[_type] !== _radio) {
          off(input, state);
        }
      } else {
        on(input, state);
      }
    }
  }

  // Add checked, disabled or indeterminate state
  function on(input, state, keep) {
    var node = input[0],
      parent = input.parent(),
      checked = state == _checked,
      indeterminate = state == _indeterminate,
      disabled = state == _disabled,
      callback = indeterminate ? _determinate : checked ? _unchecked : 'enabled',
      regular = option(input, callback + capitalize(node[_type])),
      specific = option(input, state + capitalize(node[_type]));

    // Prevent unnecessary actions
    if (node[state] !== true) {

      // Toggle assigned radio buttons
      if (!keep && state == _checked && node[_type] == _radio && node.name) {
        var form = input.closest('form'),
          inputs = 'input[name="' + node.name + '"]';

        inputs = form.length ? form.find(inputs) : $(inputs);

        inputs.each(function() {
          if (this !== node && $(this).data(_iCheck)) {
            off($(this), state);
          }
        });
      }

      // Indeterminate state
      if (indeterminate) {

        // Add indeterminate state
        node[state] = true;

        // Remove checked state
        if (node[_checked]) {
          off(input, _checked, 'force');
        }

      // Checked or disabled state
      } else {

        // Add checked or disabled state
        if (!keep) {
          node[state] = true;
        }

        // Remove indeterminate state
        if (checked && node[_indeterminate]) {
          off(input, _indeterminate, false);
        }
      }

      // Trigger callbacks
      callbacks(input, checked, state, keep);
    }

    // Add proper cursor
    if (node[_disabled] && !!option(input, _cursor, true)) {
      parent.find('.' + _iCheckHelper).css(_cursor, 'default');
    }

    // Add state class
    parent[_add](specific || option(input, state) || '');

    // Set ARIA attribute
    if (!!parent.attr('role') && !indeterminate) {
      parent.attr('aria-' + (disabled ? _disabled : _checked), 'true');
    }

    // Remove regular state class
    parent[_remove](regular || option(input, callback) || '');
  }

  // Remove checked, disabled or indeterminate state
  function off(input, state, keep) {
    var node = input[0],
      parent = input.parent(),
      checked = state == _checked,
      indeterminate = state == _indeterminate,
      disabled = state == _disabled,
      callback = indeterminate ? _determinate : checked ? _unchecked : 'enabled',
      regular = option(input, callback + capitalize(node[_type])),
      specific = option(input, state + capitalize(node[_type]));

    // Prevent unnecessary actions
    if (node[state] !== false) {

      // Toggle state
      if (indeterminate || !keep || keep == 'force') {
        node[state] = false;
      }

      // Trigger callbacks
      callbacks(input, checked, callback, keep);
    }

    // Add proper cursor
    if (!node[_disabled] && !!option(input, _cursor, true)) {
      parent.find('.' + _iCheckHelper).css(_cursor, 'pointer');
    }

    // Remove state class
    parent[_remove](specific || option(input, state) || '');

    // Set ARIA attribute
    if (!!parent.attr('role') && !indeterminate) {
      parent.attr('aria-' + (disabled ? _disabled : _checked), 'false');
    }

    // Add regular state class
    parent[_add](regular || option(input, callback) || '');
  }

  // Remove all traces
  function tidy(input, callback) {
    if (input.data(_iCheck)) {

      // Remove everything except input
      input.parent().html(input.attr('style', input.data(_iCheck).s || ''));

      // Callback
      if (callback) {
        input[_callback](callback);
      }

      // Unbind events
      input.off('.i').unwrap();
      $(_label + '[for="' + input[0].id + '"]').add(input.closest(_label)).off('.i');
    }
  }

  // Get some option
  function option(input, state, regular) {
    if (input.data(_iCheck)) {
      return input.data(_iCheck).o[state + (regular ? '' : 'Class')];
    }
  }

  // Capitalize some string
  function capitalize(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }

  // Executable handlers
  function callbacks(input, checked, callback, keep) {
    if (!keep) {
      if (checked) {
        input[_callback]('ifToggled');
      }

      input[_callback]('ifChanged')[_callback]('if' + capitalize(callback));
    }
  }
})(window.jQuery || window.Zepto);

if (typeof localTrans === 'undefined') {
    localTrans = function (phraseId, fallback)
    {
        if (typeof _localLang !== 'undefined') {
            if (typeof _localLang[phraseId] !== 'undefined') {
                if (_localLang[phraseId].length > 0) {
                    return _localLang[phraseId];
                }
            }
        }

        return fallback;
    }
}



// RactStudio Ajax Hosting Cart Script
// -----------------------------------------

jQuery(document).ready(function(){

    jQuery('#rs_ajaxhosting_cart').find('input').iCheck({
        inheritID: true,
        checkboxClass: 'icheckbox_square-default',
        radioClass: 'iradio_square-default',
        increaseArea: '20%'
    });

    if (jQuery('#inputCardNumber').length) {
        jQuery('#inputCardNumber').payment('formatCardNumber');
        jQuery('#inputCardCVV').payment('formatCardCVC');
        jQuery('#inputCardStart').payment('formatCardExpiry');
        jQuery('#inputCardExpiry').payment('formatCardExpiry');
    }

    var $orderSummaryEl = jQuery("#orderSummary");
    if ($orderSummaryEl.length) {
        var offset = jQuery("#scrollingPanelContainer").parent('.row').offset();
        var maxTopOffset = jQuery("#scrollingPanelContainer").parent('.row').outerHeight() + 100;
        jQuery(window).resize(function() {
            offset = jQuery("#scrollingPanelContainer").parent('.row').offset();
            maxTopOffset = jQuery("#scrollingPanelContainer").parent('.row').outerHeight() + 100;
            repositionScrollingSidebar();
        });
        jQuery(window).scroll(function() {
            repositionScrollingSidebar();
        });
        repositionScrollingSidebar();
    }

    function repositionScrollingSidebar() {
        if (jQuery("#scrollingPanelContainer").css('float') != 'left') {
            $orderSummaryEl.stop().css('margin-top', '0');
            return false;
        }
        var heightOfOrderSummary =  $orderSummaryEl.outerHeight();
        var offsetTop = 0;
        if (typeof offset !== "undefined") {
            offsetTop = offset.top;
        }
        var newTopOffset = jQuery(window).scrollTop() - offsetTop - 50;
        if (newTopOffset > maxTopOffset + 50) {
            newTopOffset = maxTopOffset + 50;
        }
        if (jQuery(window).scrollTop() > offsetTop) {
            $orderSummaryEl.stop().animate({
                marginTop: newTopOffset
            });
        } else {
            $orderSummaryEl.stop().animate({
                marginTop: 0
            });
        }
    }

    jQuery(".addon-products").on('click', '.panel-addon', function(e) {
        e.preventDefault();
        var $activeAddon = jQuery(this);
        if ($activeAddon.hasClass('panel-addon-selected')) {
            $activeAddon.find('input[type="checkbox"]').iCheck('uncheck');
        } else {
            $activeAddon.find('input[type="checkbox"]').iCheck('check');
        }
    });
	
    jQuery(".addon-products").on('ifChecked', '.panel-addon input', function(event) {
        var $activeAddon = jQuery(this).parents('.panel-addon');
        $activeAddon.addClass('panel-addon-selected');
        $activeAddon.find('input[type="checkbox"]').iCheck('check');
        $activeAddon.find('.panel-add').html('<i class="fa fa-shopping-cart"></i> '+localTrans('addedToCartRemove', 'Added to Cart (Remove)'));
        prodconfrecalcsummary();
    });
	
    jQuery(".addon-products").on('ifUnchecked', '.panel-addon input', function(event) {
        var $activeAddon = jQuery(this).parents('.panel-addon');
        $activeAddon.removeClass('panel-addon-selected');
        $activeAddon.find('input[type="checkbox"]').iCheck('uncheck');
        $activeAddon.find('.panel-add').html('<i class="fa fa-plus"></i> '+localTrans('addToCart', 'Add to Cart'));
        prodconfrecalcsummary();
    });
	
	
    jQuery(".addon-domains").on('click', '.panel-addon', function(e) {
        e.preventDefault();
        var $activeAddon = jQuery(this);
        if ($activeAddon.hasClass('panel-addon-selected')) {
            $activeAddon.find('input[type="checkbox"]').iCheck('uncheck');
        } else {
            $activeAddon.find('input[type="checkbox"]').iCheck('check');
        }
    });
	
    jQuery(".addon-domains").on('ifChecked', '.panel-addon input', function(event) {
        var $activeAddon = jQuery(this).parents('.panel-addon');
        $activeAddon.addClass('panel-addon-selected');
        $activeAddon.find('input[type="checkbox"]').iCheck('check');
        $activeAddon.find('.panel-add').html('<i class="fa fa-shopping-cart"></i> '+localTrans('addedToCartRemove', 'Added to Cart (Remove)'));
        domainconfigupdate();
    });
	
    jQuery(".addon-domains").on('ifUnchecked', '.panel-addon input', function(event) {
        var $activeAddon = jQuery(this).parents('.panel-addon');
        $activeAddon.removeClass('panel-addon-selected');
        $activeAddon.find('input[type="checkbox"]').iCheck('uncheck');
        $activeAddon.find('.panel-add').html('<i class="fa fa-plus"></i> '+localTrans('addToCart', 'Add to Cart'));
        domainconfigupdate();
    });
	
    jQuery(".customnsInputFields").on('ifChecked', '.customnsInput input', function(event) {
			jQuery(".addcustomns").fadeIn().removeClass('hidden').slideDown();
    });
	
    jQuery(".customnsInputFields").on('ifUnchecked', '.customnsInput input', function(event) {
			jQuery(".addcustomns").fadeOut().addClass('hidden').slideUp();
    });

    if (jQuery(".domain-selection-options input:checked").length == 0) {
        var firstInput = jQuery(".domain-selection-options input:first");
        jQuery(firstInput).iCheck('check');
        jQuery(firstInput).parents('.option').addClass('option-selected');
    }
	
    jQuery("#domain" + jQuery(".domain-selection-options input:checked").val()).show();
	
    jQuery(".domain-selection-options input").on('ifChecked', function(event){
        jQuery(".domain-selection-options .option").removeClass('option-selected');
        jQuery(this).parents('.option').addClass('option-selected');
        jQuery(".domain-input-group").hide();
        jQuery("#domain" + jQuery(this).val()).show();
    });

    // Domain Pricing Table Filters
    jQuery(".tld-filters a").click(function(e) {
        e.preventDefault();

        if (jQuery(this).hasClass('label-success')) {
            jQuery(this).removeClass('label-success');
        } else {
            jQuery(this).addClass('label-success');
        }

        jQuery('.tld-row').removeClass('filtered-row');
        jQuery('.tld-filters a.label-success').each(function(index) {
            var filterValue = jQuery(this).data('category');
            jQuery('.tld-row[data-category*="' + filterValue + '"]').addClass('filtered-row');
        });
        jQuery(".filtered-row:even").removeClass('highlighted');
        jQuery(".filtered-row:odd").addClass('highlighted');
        jQuery('.tld-row:not(".filtered-row")').fadeOut('', function() {
            if (jQuery('.filtered-row').size() == 0) {
                jQuery('.tld-row.no-tlds').show();
            } else {
                jQuery('.tld-row.no-tlds').hide();
            }
        });
        jQuery('.tld-row.filtered-row').fadeIn();
    });
    jQuery(".filtered-row:even").removeClass('highlighted');
    jQuery(".filtered-row:odd").addClass('highlighted');
	
    jQuery("#btnAlreadyRegistered").click(function() {
        jQuery("#containerNewUserSignup").slideUp('', function() {
            jQuery("#containerExistingUserSignin").hide().removeClass('hidden').slideDown('', function() {
                jQuery("#inputCustType").val('existing');
                jQuery("#btnAlreadyRegistered").fadeOut('', function() {
                    jQuery("#btnNewUserSignup").removeClass('hidden').fadeIn();
                });
            });
        });
        jQuery("#containerNewUserSecurity").hide();
        if (jQuery("#stateselect").attr('required')) {
            jQuery("#stateselect").removeAttr('required').addClass('requiredAttributeRemoved');
        }
    });

    jQuery("#btnNewUserSignup").click(function() {
        jQuery("#containerExistingUserSignin").slideUp('', function() {
            jQuery("#containerNewUserSignup").hide().removeClass('hidden').slideDown('', function() {
                jQuery("#inputCustType").val('new');
                jQuery("#containerNewUserSecurity").show();
                jQuery("#btnNewUserSignup").fadeOut('', function() {
                    jQuery("#btnAlreadyRegistered").removeClass('hidden').fadeIn();
                });
            });
        });
        if (jQuery("#stateselect").hasClass('requiredAttributeRemoved')) {
            jQuery("#stateselect").attr('required', 'required').removeClass('requiredAttributeRemoved');
        }
    });

    jQuery(".payment-methods").on('ifChecked', function(event) {
        if (jQuery(this).hasClass('is-credit-card')) {
            if (!jQuery("#creditCardInputFields").is(":visible")) {
                jQuery("#creditCardInputFields").hide().removeClass('hidden').slideDown();
            }
        } else {
            jQuery("#creditCardInputFields").slideUp();
        }
    });

    jQuery("input[name='ccinfo']").on('ifChecked', function(event) {
        if (jQuery(this).val() == 'new') {
            jQuery("#existingCardInfo").slideUp('', function() {
                jQuery("#newCardInfo").hide().removeClass('hidden').slideDown();
            });
        } else {
            jQuery("#newCardInfo").slideUp('', function() {
                jQuery("#existingCardInfo").hide().removeClass('hidden').slideDown();
            });
        }
    });

    jQuery("#inputDomainContact").on('change', function() {
        if (this.value == "addingnew") {
            jQuery("#domainRegistrantInputFields").hide().removeClass('hidden').slideDown();
        } else {
            jQuery("#domainRegistrantInputFields").slideUp();
        }
    });

    jQuery("#inputNewPassword1").keyup(function () {
        passwordStrength = getPasswordStrength(jQuery(this).val());
        if (passwordStrength >= 75) {
            textLabel = langPasswordStrong;
            cssClass = 'success';
        } else if (passwordStrength >= 30) {
            textLabel = langPasswordModerate;
            cssClass = 'warning';
        } else {
            textLabel = langPasswordWeak;
            cssClass = 'danger';
        }
        jQuery("#passwordStrengthTextLabel").html(langPasswordStrength + ': ' + passwordStrength + '% ' + textLabel);
        jQuery("#passwordStrengthMeterBar").css('width', passwordStrength + '%').attr('aria-valuenow', passwordStrength);
        jQuery("#passwordStrengthMeterBar").removeClass('progress-bar-success progress-bar-warning progress-bar-danger').addClass('progress-bar-' + cssClass);
    });

    jQuery("#cardType li a").click(function (e) {
        e.preventDefault();
        jQuery("#selectedCardType").html(jQuery(this).html());
        jQuery("#cctype").val(jQuery('span.type', this).html());
    });

});

function selectDomainPricing(domainName, price, period, yearsString, suggestionNumber) {
    jQuery("#domainSuggestion" + suggestionNumber).iCheck('check');
    jQuery("[name='domainsregperiod[" + domainName + "]']").val(period);
    jQuery("[name='" + domainName + "-selected-price']").html('<b class="glyphicon glyphicon-shopping-cart"></b>'
        + ' ' + period + ' ' + yearsString + ' @ ' + price);
}

function selectDomainPeriodInCart(domainName, price, period, yearsString) {
    var loader = jQuery("#cartloader");
    if (loader.hasClass('hidden')) {
        loader.hide().removeClass('hidden').fadeIn('fast');
    }
    jQuery("[name='" + domainName + "Pricing']").html(period + ' ' + yearsString + ' <span class="caret"></span>');
    jQuery("[name='" + domainName + "Price']").html(price);
    var update = jQuery.post(
        window.location.pathname,
        {
            domain: domainName,
            period: period,
            a: 'updateDomainPeriod',
            token: csrfToken
        }
    );
    update.done(
        function(data) {
            data.domains.forEach(function(domain) {
                jQuery("[name='" + domain.domain + "Price']").parent('div').find('.renewal-price').html(
                    domain.renewprice + domain.shortYearsLanguage
                ).end();
            });
            jQuery('#subtotal').html(data.subtotal);
            if (data.promotype) {
                jQuery('#discount').html(data.discount);
            }
            if (data.taxrate) {
                jQuery('#taxTotal1').html(data.taxtotal);
            }
            if (data.taxrate2) {
                jQuery('#taxTotal2').html(data.taxtotal2);
            }

            var recurringSpan = jQuery('#recurring');

            recurringSpan.find('span:visible').not('span.cost').fadeOut('fast').end();

            if (data.totalrecurringannually) {
                jQuery('#recurringAnnually').fadeIn('fast').find('.cost').html(data.totalrecurringannually);
            }

            if (data.totalrecurringbiennially) {
                jQuery('#recurringBiennially').fadeIn('fast').find('.cost').html(data.totalrecurringbiennially);
            }

            if (data.totalrecurringmonthly) {
                jQuery('#recurringMonthly').fadeIn('fast').find('.cost').html(data.totalrecurringmonthly);
            }

            if (data.totalrecurringquarterly) {
                jQuery('#recurringQuarterly').fadeIn('fast').find('.cost').html(data.totalrecurringquarterly);
            }

            if (data.totalrecurringsemiannually) {
                jQuery('#recurringSemiAnnually').fadeIn('fast').find('.cost').html(data.totalrecurringsemiannually);
            }

            if (data.totalrecurringtriennially) {
                jQuery('#recurringTriennially').fadeIn('fast').find('.cost').html(data.totalrecurringtriennially);
            }

            jQuery('#totalDueToday').html(data.total);
        }
    );
    update.always(
        function() {
            loader.delay(100).fadeOut('slow').addClass('hidden').show();
        }
    );
}


// Main JavaScript Code of RactStudio Ajax Cart
// ----------------------------------------------

var signupStep = false;

$(document).ready(function(){
    recalcsummary();
    jQuery("#cartsummary").makeFloat({x:"current",y:"current"});
    signupStep = false;
});

function selectproduct(pid) {
    jQuery("#checkoutbtn").hide();
    jQuery("#loading1").slideDown(function() {
			jQuery('html, body').animate({scrollTop: jQuery("#rs_ajaxhosting_cart").offset().top-5});
		});
    jQuery("#configcontainer1").fadeOut();
    jQuery("#configcontainer2").fadeOut();
    jQuery("#configcontainer3").fadeOut();
    jQuery("#signupcontainer").fadeOut();
    signupStep = false;
    jQuery.post("cart.php", 'ajax=1&a=add&pid='+pid,
    function(data){
        if (data=='') {
            signupstep();
        } else {
            jQuery("#configcontainer1").html(data);
            jQuery("#configcontainer1").slideDown();
        }
        jQuery("#loading1").slideUp(function() {
			var tab = $(this).closest('.tab-pane');
			$('#' + tab[0].id + ', .nav-tabs li').removeClass('active');
			$('.nav-tabs li a[href="#' + tab.next()[0].id + '"]').parent().addClass('active');
			tab.next().addClass('active');
			jQuery('html, body').animate({scrollTop: jQuery("#rs_ajaxhosting_cart").offset().top-5});
		});
        recalcsummary();
    });
}

function recalcsummary() {
    jQuery("#cartloader").show();
    jQuery.post("cart.php", 'a=view&cartsummary=1&ajax=1',
    function(data){
        jQuery("#cartsummary").html(data);
        jQuery("#cartloader").hide();
    });
}

function prodconfrecalcsummary() {
    jQuery("#cartloader").show();
    signupStep = false;
	jQuery.post("cart.php", 'ajax=1&a=confproduct&calctotal=true&' + jQuery("#orderfrm").serialize(),
    function(data){
        jQuery.post("cart.php", 'a=view&cartsummary=1&ajax=1',
        function(data){
            jQuery("#cartsummary").html(data);
            jQuery("#cartloader").hide();
        });
    });
}

jQuery("#ConfigProduct").click(function() {
	jQuery("#ProductConfig").slideUp(function() {
		jQuery("#ProductConfig").removeClass('hidden').slideDown(function() {
			jQuery("#DomainsConfig").addClass('hidden').slideUp();
			jQuery("#DomainName").addClass('hidden').slideUp();
			jQuery('html, body').animate({scrollTop: jQuery("#rs_ajaxhosting_cart").offset().top-5});
		});
	});
});

jQuery("#NameDomain").click(function() {
	jQuery("#DomainName").slideUp(function() {
		jQuery("#DomainName").removeClass('hidden').slideDown(function() {
			jQuery("#DomainsConfig").addClass('hidden').slideUp();
			jQuery("#ProductConfig").addClass('hidden').slideUp();
			jQuery('html, body').animate({scrollTop: jQuery("#rs_ajaxhosting_cart").offset().top-5});
		});
	});
});

jQuery("#ConfigDomains").click(function() {
	jQuery("#DomainsConfig").slideUp(function() {
		jQuery("#DomainsConfig").removeClass('hidden').slideDown(function() {
			jQuery("#DomainName").addClass('hidden').slideUp();
			jQuery("#ProductConfig").addClass('hidden').slideUp();
			jQuery('html, body').animate({scrollTop: jQuery("#rs_ajaxhosting_cart").offset().top-5});
		});
	});
});

function prodconfcomplete() {
    jQuery("#prodconfloading").slideDown();
    signupStep = false;

	var button = jQuery('#btnProductConfig');
	var btnOriginalText = jQuery(button).html();
	jQuery(button).find('i').removeClass('fa-chevron-right').addClass('fa-spinner fa-spin');
	
    jQuery.post("cart.php", 'a=confproduct&ajax=1&'+jQuery("#orderfrm").serialize(),
    function(data){
        if (data) {
            jQuery("#configproducterror").html(data);
			
			jQuery("#containerProductValidationErrorsList").html(data);
			jQuery("#containerProductValidationErrors").removeClass('hidden').show();
			// scroll to error container if below it
			if (jQuery(window).scrollTop() > jQuery("#containerProductValidationErrors").offset().top) {
				jQuery('html, body').scrollTop(jQuery("#containerProductValidationErrors").offset().top - 15);
			}
			
            jQuery("#configproducterror").slideDown(function(){
						jQuery(button).find('i').removeClass('fa-spinner fa-spin').addClass('fa-chevron-right');
					});
            jQuery("#prodconfloading").slideUp();
        } else {
            jQuery.post("cart.php", 'a=confdomains&ajax=1',
            function(data){
                if (data) {
                    jQuery("#configcontainer3").html(data);
                    jQuery("#configcontainer3").slideDown();
					jQuery("#btnProductConfig").html(btnOriginalText);
                    jQuery("#configproducterror").slideUp();
                    jQuery("#prodconfloading").slideUp();
					
					jQuery("#DomainsConfig").removeClass('hidden').slideDown();
					jQuery("#DomainName").addClass('hidden').slideUp();
					jQuery("#ProductConfig").addClass('hidden').slideUp();
					jQuery('html, body').animate({scrollTop: jQuery("#rs_ajaxhosting_cart").offset().top-5});
					
					} else {
                    jQuery("#configproducterror").slideUp();
                    signupstep();
                }
				jQuery(button).find('i').removeClass('fa-spinner fa-spin').addClass('fa-chevron-right');
            });
        }
    });

}

function checkdomain() {
    var domainoption = jQuery(".domainoptions input:checked").val();
    var sld = jQuery("#"+domainoption+"sld").val();
    var tld = '';
    if (domainoption=='incart') var sld = jQuery("#"+domainoption+"sld option:selected").text();
    if (domainoption=='subdomain') var tld = jQuery("#"+domainoption+"tld option:selected").text();
    else var tld = jQuery("#"+domainoption+"tld").val();
    jQuery("#loading3").slideDown();
    signupStep = false;
    jQuery.post("cart.php", { a: "domainoptions", ajax: 1, sld: sld, tld: tld, checktype: domainoption },
    function(data){
        jQuery("#domainresults").html(data);
        jQuery("#domainresults").slideDown();
        jQuery("#loading3").slideUp();
    });
}

function domainconfigupdate() {
    signupStep = false;
    jQuery.post("cart.php", 'a=confdomains&update=1&ajax=1&'+jQuery("#domainconfigfrm").serialize(),
    function(data){
        recalcsummary();
    });
}

function completedomainconfig() {
    jQuery("#domainconfloading").slideUp();
    signupStep = false;

	var button = jQuery('#btnDomainConfig');
	var btnOriginalText = jQuery(button).html();
	jQuery(button).find('i').removeClass('fa-chevron-right').addClass('fa-spinner fa-spin');
	
    jQuery.post("cart.php", 'a=confdomains&update=1&ajax=1&'+jQuery("#domainconfigfrm").serialize(),
    function(data){
        if (data) {
            jQuery("#configdomainerror").html(data);
			
			jQuery("#containerDomainValidationErrorsList").html(data);
			jQuery("#containerDomainValidationErrors").removeClass('hidden').show();
			// scroll to error container if below it
			if (jQuery(window).scrollTop() > jQuery("#containerDomainValidationErrors").offset().top) {
				jQuery('html, body').scrollTop(jQuery("#containerDomainValidationErrors").offset().top - 15);
			}
			
            jQuery("#configdomainerror").slideDown(function(){
						jQuery(button).find('i').removeClass('fa-spinner fa-spin').addClass('fa-chevron-right');
					});
            jQuery("#domainconfloading").slideUp();
        } else {
			jQuery("#btnDomainConfig").html(btnOriginalText);
            jQuery("#configdomainerror").slideUp();
            signupstep();
        }
    });
}

function signupstep() {
    signupStep = true;
    jQuery.post("cart.php", 'a=checkout&ajax=1',
    function(data){
        jQuery("#signupcontainer").html(data);
        jQuery("#signupcontainer").slideDown();
        jQuery("#prodconfloading").slideUp(function() {
			var tab = $(this).closest('.tab-pane');
			$('#' + tab[0].id + ', .nav-tabs li').removeClass('active');
			$('.nav-tabs li a[href="#' + tab.next()[0].id + '"]').parent().addClass('active');
			tab.next().addClass('active');
			jQuery('html, body').animate({scrollTop: jQuery("#rs_ajaxhosting_cart").offset().top-5});
		});
        jQuery("#domainconfloading").slideUp(function() {
			var tab = $(this).closest('.tab-pane');
			$('#' + tab[0].id + ', .nav-tabs li').removeClass('active');
			$('.nav-tabs li a[href="#' + tab.next()[0].id + '"]').parent().addClass('active');
			tab.next().addClass('active');
			jQuery('html, body').animate({scrollTop: jQuery("#rs_ajaxhosting_cart").offset().top-5});
		});
    });
}

function checkout() {
    jQuery.post("cart.php", 'a=checkout&ajax=1',
    function(data){
        jQuery("#signupcontainer").html(data);
        jQuery("#signupcontainer").slideDown();
		jQuery('html, body').animate({scrollTop: jQuery("#rs_ajaxhosting_cart").offset().top-5});
    });
}

function showsignupfields() {
    jQuery(".signupfields").show();
    jQuery(".loginfields").hide();
};

function showloginfields() {
    jQuery(".signupfields").hide();
    jQuery(".loginfields").show();
};

function completeorder() {
    jQuery("#checkoutloader").slideDown();
	
	var button = jQuery('#btnCompleteOrder');
	var btnOriginalText = jQuery(button).html();
	jQuery(button).find('i').removeClass('fa-chevron-right').addClass('fa-spinner fa-spin');
	
    jQuery.post("cart.php", 'a=checkout&$checkout=1&ajax=1&'+jQuery("#checkoutfrm").serialize(),
    function(data){
        if (data) {
            jQuery("#checkouterror").html(data);
			
			jQuery("#containerCheckoutValidationErrorsList").html(data);
			jQuery("#containerCheckoutValidationErrors").removeClass('hidden').show();
			// scroll to error container if below it
			if (jQuery(window).scrollTop() > jQuery("#containerCheckoutValidationErrors").offset().top) {
				jQuery('html, body').scrollTop(jQuery("#containerCheckoutValidationErrors").offset().top - 15);
			}
			
            jQuery("#checkouterror").slideDown(function(){
					jQuery(button).find('i').removeClass('fa-spinner fa-spin').addClass('fa-chevron-right');
				});
            jQuery("#checkoutloader").slideUp();
			jQuery("#btnCompleteOrder").html(btnOriginalText);
        } else {
            window.location = 'cart.php?a=fraudcheck';
        }
    });
}

function domaincontactchange() {
    if (jQuery("#domaincontact").val()=="addingnew") {
        jQuery("#domaincontactfields").slideDown();
    } else {
        jQuery("#domaincontactfields").slideUp();
    }
}

function currencychange() {
    jQuery("#cartloader").show();
    jQuery.post("cart.php", 'a=view&cartsummary=1&ajax=1&currency='+jQuery("#currency").val(),
    function(data){
        jQuery("#cartsummary").html(data);
        jQuery("#cartloader").hide();
    });
}

function applypromo() {
	var button = jQuery('#btnApplyPromo');
	var btnOriginalText = jQuery(button).html();
	jQuery(button).find('i').removeClass('fa-chevron-right').addClass('fa-spinner fa-spin');
	
    jQuery.post("cart.php", { a: "applypromo", promocode: jQuery("#promocode").val() },
    function(data){
        if (data) {
			jQuery("#btnApplyPromo").html(btnOriginalText);
			alert(data);
		}
        else recalcsummary();
    });
    /**
     * If the signupStep has been reached, redo the checkout in order to validate
     * the promotion code with the bundle if applicable.
     */
    if (signupStep) {
        signupstep();
    }
}

function removepromo() {
    jQuery.post("cart.php", { a: "removepromo", ajax: 1 },
    function(data){
        recalcsummary();
    });
    /**
     * If the signupStep has been reached, redo the checkout in order to validate
     * the promotion code removal with the bundle if applicable.
     */
    if (signupStep) {
        signupstep();
    }
}

function addonaddtocart(addonid,i) {
    jQuery.post("cart.php", { a: "add", ajax: 1, aid: addonid, productid: jQuery("#addonpid"+i).val() },
    function(data){
        recalcsummary();
    });
}

function renewaladdtocart(domainid,i) {
    jQuery.post("cart.php", { a: "add", renewals: 1, ajax: 1, renewalid: domainid, renewalperiod: jQuery("#renewalperiod"+i).val() },
    function(data){
        recalcsummary();
    });
}


(function($){
/*----------------------------------------------------------------------------------
Class: FloatObject
-------------------------------------------------------------------------------------*/
    function FloatObject(jqObj, params)
    {
        this.jqObj = jqObj;

        switch(params.speed)
        {
            case 'fast': this.steps = 5; break;
            case 'normal': this.steps = 10; break;
            case 'slow': this.steps = 20; break;
            default: this.steps = 10;
        };

        var offset = this.jqObj.offset();
        this.currentX = offset.left;
        this.currentY = offset.top;
        this.width = this.jqObj.width();
        this.height = this.jqObj.height();
        this.alwaysVisible = params.alwaysVisible;
        this.alwaysTop = params.alwaysTop;


        this.origX = typeof(params.x) == "string" ?  this.currentX : params.x;
        this.origY = typeof(params.y) == "string" ?  this.currentY : params.y;


        //now we make sure the object is in absolute positions.
        this.jqObj.css({'position':'auto' , 'bottom':this.currentY ,'left':this.currentX});
    }

    FloatObject.prototype.updateLocation = function()
    {
        this.updatedX = $(window).scrollLeft() + this.origX;

        if( this.alwaysTop == false ){
            if ($(window).scrollTop() > this.origY ) {
this.updatedY = $(window).scrollTop() + 5;
} else {
this.updatedY = $(window).scrollTop()+ this.origY;
}

            if( this.alwaysVisible ){
                if( this.origX + this.width > this.windowWidth() )
                    this.updatedX = this.windowWidth() - this.width + $(window).scrollLeft();
                if( this.origY + this.height > this.windowHeight() )
                {
                    this.updatedY = $(window).scrollTop() + this.windowHeight() - this.height;
                    if( this.updatedY < this.origY ) this.updatedY = this.origY;
                }
            }
        }
        else
        {

            if( $(window).scrollTop() > this.origY )
            {
                this.updatedY = $(window).scrollTop() + 5;
            }
            else
            {
                this.updatedY = this.origY + 5;
            }
        }
        this.dx = Math.abs(this.updatedX - this.currentX );
        this.dy = Math.abs(this.updatedY - this.currentY );

        return this.dx || this.dy;
    }

    FloatObject.prototype.windowHeight = function()
    {
        var de = document.documentElement;

        return self.innerHeight ||
            (de && de.clientHeight) ||
            document.body.clientHeight;
    }

    FloatObject.prototype.windowWidth = function()
    {
        var de = document.documentElement;

        return self.innerWidth ||
            (de && de.clientWidth) ||
            document.body.clientWidth;
    }


    FloatObject.prototype.move = function()
    {
        if( this.jqObj.css("position") != "absolute" ) return;
        var cx = 0;
        var cy = 0;

        if( this.dx > 0 )
        {
            if( this.dx < this.steps / 2 )
                cx = (this.dx >= 1) ? 1 : 0;
            else
                cx = Math.round(this.dx/this.steps);

            if( this.currentX < this.updatedX )
                this.currentX += cx;
            else
                this.currentX -= cx;
        }

        if( this.dy > 0 )
        {
            if( this.dy < this.steps / 2 )
                cy = (this.dy >= 1) ? 1 : 0;
            else
                cy = Math.round(this.dy/this.steps);

            if( this.currentY < this.updatedY )
                this.currentY += cy;
            else
                this.currentY -= cy;
        }

        this.jqObj.css({'left':this.currentX, 'top': this.currentY });
    }



/*----------------------------------------------------------------------------------
Object: floatMgr
-------------------------------------------------------------------------------------*/
    $.floatMgr = {

        FOArray: new Array() ,

        timer: null ,

        initializeFO: function(jqObj,params)
        {
            var settings =  $.extend({
                x: 0 ,
                y: 0 ,
                speed: 'normal' ,
                alwaysVisible: false ,
                alwaysTop: false},params||{});
            var newFO = new FloatObject(jqObj,settings);

            $.floatMgr.FOArray.push(newFO);

            if( !$.floatMgr.timer ) $.floatMgr.adjustFO();

            //now making sure we are registered to all required window events
            if( !$.floatMgr.registeredEvents )
            {
                    $(window).bind("resize", $.floatMgr.onChange);
                    $(window).bind("scroll", $.floatMgr.onChange);
                    $.floatMgr.registeredEvents = true;
            }
        } ,

        adjustFO: function()
        {
            $.floatMgr.timer = null;

            var moveFO = false;

            for( var i = 0 ; i < $.floatMgr.FOArray.length ; i++ )
            {
                 FO = $.floatMgr.FOArray[i];
                 if( FO.updateLocation() )  moveFO = true;
            }

            if( moveFO )
            {
                for( var i = 0 ; i < $.floatMgr.FOArray.length ; i++ )
                {
                    FO = $.floatMgr.FOArray[i];
                    FO.move();
                }

                if( !$.floatMgr.timer ) $.floatMgr.timer = setTimeout($.floatMgr.adjustFO,50);
            }
        }   ,

        stopFloatChk: false ,

        onChange: function()
        {
            if( !$.floatMgr.timer && !$.floatMgr.stopFloatChk ) $.floatMgr.adjustFO();
        }
    };

/*----------------------------------------------------------------------------------
Function: makeFloat
-------------------------------------------------------------------------------------*/
    $.fn.makeFloat = function(params) {
        var obj = this.eq(0); //we only operate on the first selected object;
        $.floatMgr.initializeFO(obj,params);
        if( $.floatMgr.timer == null ) $.floatMgr.adjustFO();
        return obj;
    };
    $.fn.stopFloat = function(params) {
        $.floatMgr.stopFloatChk = true;
    };

    $.fn.restartFloat = function(params) {
        $.floatMgr.stopFloatChk = false;
    };
})(jQuery);